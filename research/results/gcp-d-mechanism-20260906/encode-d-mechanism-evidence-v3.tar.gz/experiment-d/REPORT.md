# Arm D uncapped-token mechanism validation

## Policy

This is a new revision. It does not overwrite the prior **fixed-budget development experiment — 16,000 tokens/task**. Arm D has no research token budget; token use is measured cost. A separate 250,000-token operational emergency ceiling is reported independently. The frozen 20-task development selection was used. Held-out data was not used.

## Result

- Official pass rate: 40.0%
- Tasks with >=1 / >=2 / >=3 genuine cycles: 14 / 4 / 1
- Median genuine cycles/task: 1.0
- Median tokens/genuine cycle: 23,384
- Recoverable first-attempt failures: 8
- Successful recoveries: 2
- Recovery yield: 25.0%
- False fulfilment rate: 50.0%
- False unfulfilment rate: 38.9%
- Emergency-ceiling terminations: 1

Recovered tasks: 120-24, 37554.

## Decision gate

**INVESTIGATE IMPLEMENTATION; do not rerun four arms.** Recovery is non-zero and 19/20 tasks avoided the emergency ceiling, but only four tasks completed two or more genuine cycles, so the requirement that multi-cycle reconciliation operate on most tasks needing it is not met. High false-unfulfilment and false-fulfilment also show evaluator/termination defects.

Raw task/cycle accounting is in `run/D/mechanism_analysis.json`; official results, every mutation checkpoint, traces, contracts, discrepancies, hashes, and append-only evidence are retained alongside it.
